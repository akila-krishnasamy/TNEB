# TNEB-Bill-Calculator
A Web Based application for calculating the electricity bill amount based on the units consumed.
