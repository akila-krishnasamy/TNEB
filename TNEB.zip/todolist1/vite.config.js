export default {
  build: {
    rollupOptions: {
      input: 'index.html'
    }
  }
}